//
//  ViewController.swift
//  iTip
//
//  Created by Fabio Ribeiro on 2/8/16.
//  Copyright © 2016 Fabio Ribeiro. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    @IBOutlet weak var tip15: UILabel!
    @IBOutlet weak var tot15: UILabel!
    @IBOutlet weak var tipStepper: UIStepper!
    @IBOutlet weak var personsStepper: UIStepper!
    @IBOutlet weak var varTipRate: UILabel!
    @IBOutlet weak var partyDisplay: UITextField!
    @IBOutlet weak var partyName: UILabel!
    @IBOutlet weak var tipVar: UILabel!
    @IBOutlet weak var totVar: UILabel!
    @IBOutlet weak var checkTotal: UITextField!
    @IBOutlet weak var totVarEach: UILabel!
    @IBOutlet weak var tipVarEach: UILabel!
    @IBOutlet weak var each: UILabel!
    
    var varTipRounded: Double = 18
    var party = 1
    

        
    
    
    
    @IBAction func tipStepperChanged(sender: AnyObject) {
        
        
    
        
        varTipRounded = round(tipStepper.value * 100)/100
        
        varTipRate.text = String(varTipRounded) + "%"

        totalInput(tipStepper)
        
        
        
    }
    
    
    @IBAction func personStepperChanged(sender: AnyObject) {
        
        partyDisplay.text = String(Int(personsStepper.value))
        party = Int(personsStepper.value)
        
        if Int(personsStepper.value) > 1 {
            
            partyName.text = "people"
            each.text = "each"
        }
        else {
            
            partyName.text = "person"
            each.text = ""

        }
        
        totalInput(personsStepper)

        
    }
    
    


    @IBAction func totalInput(sender: AnyObject) {
        
     
        if let check = Double(checkTotal.text!) {
            
            
            tipVar.text = String(format: "%.2f",Double(check) * varTipRounded / 100)
            totVar.text = String(format: "%.2f",Double(check) * (1 + (varTipRounded) / 100))
            
            tip15.text = String(format: "%.2f",Double(check) * 15 / 100)
            tot15.text = String(format: "%.2f",Double(check) * 115 / 100)

            if Int(personsStepper.value) > 1 {

            
                totVarEach.text = String(format: "%.2f",((Double(check) * varTipRounded) + Double(check)) / Double(party) / 10)
                tipVarEach.text = String(format: "%.2f", Double(check) * varTipRounded / Double(party) / 100)
           //   totVarEach.text = String(format: "%.2f",Double(check) * (1 + (varTipRounded / Double(party) / 100)))
                
            }
            else {
                        
                        totVarEach.text = ""
                        tipVarEach.text = ""
                        totVarEach.text = ""
                        tipVarEach.text = ""

                        
            }
                

                
                
        }
        
            
        else {
            
            tipVar.text = ""
            totVar.text = ""
            totVarEach.text = ""
            
            tipVarEach.text = ""
            totVarEach.text = ""
            tipVarEach.text = ""
            
            tip15.text = ""
            tot15.text = ""
            
        }

        

}

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

