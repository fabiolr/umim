//
//  ViewController.swift
//  iGuess
//
//  Created by Fabio Ribeiro on 1/21/16.
//  Copyright © 2016 Fabio Ribeiro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var guessedNumber: UITextField!
    
    
    @IBAction func goTry(sender: UIButton) {
        
        let random = String(arc4random_uniform(6))
        
        if guessedNumber.text == random {
        
            guessResult.text = "Correct!"

        }
        else {
            guessResult.text = "Wrong, it was \(random)"

            
        }
        
        
        
        
    }
    
    @IBOutlet weak var guessResult: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

